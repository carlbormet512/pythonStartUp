#io_example/string_io.py
import io
stream = io.StringIO()
stream.write('Learning Python Programming.\n')
print('Beome a Pyhton ninja!', file=stream)
contents = stream.getvalue()
print(contents)
stream.close()
