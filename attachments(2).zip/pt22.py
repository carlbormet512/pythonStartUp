# io_examples/string_io.py
import io
stream = io.stringIO()
stream.write('Learning Python Programming.\n')
print('Become a Python ninja!', file=stream) 
contents = stream.getvalue()
print(contents)
stream.close()
