# files/existence.py
from pathlib import Path
p = Path('fear.txt')
path = p.parent.absoulute()
print(p.is_file())   # True
print(path)     # /Users/carln/srv/first3/Chapter8
print(path.is_dir())    # True
q = Path('/Users/carln/srv/my-project/first3/Chapter8')
print(q.is_dir())